/*
 * Copyright (c) 2016 Intel Corporation
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/devicetree.h>
/* STEP 3 - Include the header file of the I2C API */
#include <zephyr/drivers/i2c.h>
/* STEP 4.1 - Include the header file of printk() */
#include <zephyr/sys/printk.h>
/* 1000 msec = 1 sec */
#define SLEEP_TIME_MS 1000

/* STEP 8 - Define the I2C slave device address and the addresses of relevant registers */
#define BME680_TEMP_xlsb 	0x24
#define BME680_TEMP_lsb  	0x23
#define BME680_TEMP_msb  	0x22
#define BME680_SLAVE    	0x76
#define BME680_SLAVE_W    	0xEC
#define BME680_SLAVE_R    	0xED
#define BME680_par_t1_lsb  	0xE9
#define BME680_par_t1_msb  	0xEA
#define BME680_par_t2_lsb  	0x8A
#define BME680_par_t2_msb  	0x8B
#define BME680_par_t3  		0x8C


/* STEP 6 - Get the node identifier of the sensor */
#define I2C_NODE DT_NODELABEL(mysensor)

int main(void)
{

	int ret;

	/* STEP 7 - Retrieve the API-specific device structure and make sure that the device is
	 * ready to use  */
	static const struct i2c_dt_spec dev_i2c = I2C_DT_SPEC_GET(I2C_NODE);
	if (!device_is_ready(dev_i2c.bus)) {
		printk("I2C bus %s is not ready!\n", dev_i2c.bus->name);
		return -1;
	}

	/* STEP 9 - Setup the sensor by writing to the slave write register, then control bits, then slave read */
	uint8_t config[3] = {BME680_SLAVE_W, BME680_TEMP_lsb, BME680_SLAVE_R};
	ret = i2c_write_dt(&dev_i2c, config, sizeof(config));
	if (ret != 0) {
		printk("Failed to write to I2C device address %x at Reg. %x \n", dev_i2c.addr,
		       config[0]);
		return -1;
	}

	while (1) {
		/* STEP 10 - Read the temperature from the sensor */
		uint8_t temp_reading[2] = {0};
		uint8_t sensor_regs[2] = {BME680_TEMP_lsb, BME680_TEMP_msb};
		ret = i2c_write_read_dt(&dev_i2c, &sensor_regs[0], 1, &temp_reading[0], 1);
		if (ret != 0) {
			printk("Failed to write/read I2C device address %x at Reg. %x \n",
			       dev_i2c.addr, sensor_regs[0]);
		}
		ret = i2c_write_read_dt(&dev_i2c, &sensor_regs[1], 1, &temp_reading[1], 1);
		if (ret != 0) {
			printk("Failed to write/read I2C device address %x at Reg. %x \n",
			       dev_i2c.addr, sensor_regs[1]);
		}

		/* READ CALIBRRATION PARAMETERS */

		uint8_t cal_reading[5] = {0};
		uint8_t cal_regs[5] = {BME680_par_t1_lsb, BME680_par_t1_msb, BME680_par_t2_lsb, BME680_par_t2_msb, BME680_par_t3};
		ret = i2c_write_read_dt(&dev_i2c, &cal_regs[0], 1, &cal_reading[0], 1);
		if (ret != 0) {
			printk("Failed to write/read I2C device address %x at Reg. %x \n",
			       dev_i2c.addr, cal_regs[0]);
		}
		ret = i2c_write_read_dt(&dev_i2c, &cal_regs[1], 1, &cal_reading[1], 1);
		if (ret != 0) {
			printk("Failed to write/read I2C device address %x at Reg. %x \n",
			       dev_i2c.addr, cal_regs[1]);
		}
		ret = i2c_write_read_dt(&dev_i2c, &cal_regs[2], 1, &cal_reading[2], 1);
		if (ret != 0) {
			printk("Failed to write/read I2C device address %x at Reg. %x \n",
			       dev_i2c.addr, cal_regs[2]);
		}
		ret = i2c_write_read_dt(&dev_i2c, &cal_regs[3], 1, &cal_reading[3], 1);
		if (ret != 0) {
			printk("Failed to write/read I2C device address %x at Reg. %x \n",
			       dev_i2c.addr, cal_regs[3]);
		}
		ret = i2c_write_read_dt(&dev_i2c, &cal_regs[4], 1, &cal_reading[4], 1);
		if (ret != 0) {
			printk("Failed to write/read I2C device address %x at Reg. %x \n",
			       dev_i2c.addr, cal_regs[4]);
		}

		/* STEP 11 - Convert the two bytes to a 12-bits */
		int temp = ((int)temp_reading[1] * 256 + ((int)temp_reading[0] & 0xF0)) / 16;
		if (temp > 2047) {
			temp -= 4096;
		}

		// Convert to engineering units
		double cTemp = temp * 0.0625;
		double fTemp = cTemp * 1.8 + 32;

		// Print reading to console
		printk("Temperature in Celsius : %.2f C \n", cTemp);
		printk("Temperature in Fahrenheit : %.2f F \n", fTemp);
		k_msleep(SLEEP_TIME_MS);
	}
}